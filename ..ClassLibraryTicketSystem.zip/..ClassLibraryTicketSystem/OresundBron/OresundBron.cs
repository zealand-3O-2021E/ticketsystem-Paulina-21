﻿using ClassLibraryTicketSystem;
using System;

namespace OresundBron
{
    public class OresundBron
    {
        public double VehicleDiscountedPrice(Vehicle v)
        {
            if (v.GetType() == typeof(Car))
            {
                v.DefaultPrice = 410;
                if (v.Brobizz == true)
                {
                    v.DefaultPrice = 161;
                }
                    
            }

            if (v.GetType() == typeof(MC))
            {
                v.DefaultPrice = 210;
                if (v.Brobizz == true)
                {
                    v.DefaultPrice = 73;
                }
                    
            }

            return v.DefaultPrice;
        }

        public string VehicleType(Vehicle v)
        {
            return "Oresund " + v.VehicleType();
        }
    }
}
